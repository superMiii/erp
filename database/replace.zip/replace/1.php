<?php
$folder = glob("models/*/*.php");
foreach($folder as $src){
//echo $src.'<br>';
	$kode = '$kode';
	$thbl = '$thbl';
	$files = file_get_contents($src);
	$rep = str_replace("AND substring(i_document, 1, 2) = '$kode'", "AND substring(i_document, 1, 2) = '$kode'\n
            AND substring(i_document, 4, 2) = substring('$thbl',1,2)",$files);

	//$rep2 = str_replace(',tr_', ', ".com().".tr_',$files);

	file_put_contents($src,$rep);
	//file_put_contents($src,$rep2);

}

?>