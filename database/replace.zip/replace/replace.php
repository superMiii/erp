<?php
$folder = glob("views/*/*.php");
foreach($folder as $src){
//echo $src.'<br>';
	/*$kode = '$this';
	$no   = '$number';*/


	/*$string = <<< 'EOT'
	to_char (d_pp, 'yyyy') >= '".date('Y')."'
	EOT;

	$replace = <<< 'EOT'
	to_char (d_pp, 'yyyy') >= '$tahun'
	EOT;*/

	/*$striang = <<< 'EOT'
	$sdtring = "This is string";
	EOT;

	$replace = <<< 'EOT'
	$dtring = "This is word";
	EOT;*/
	$files 	= file_get_contents($src);
	$rep  	= str_replace("bg-success", "bg-teal", $files);
	file_put_contents($src,$rep);
	/*
	$rep  = str_replace("showCalendar", "AND substring(i_adjustment, 1, 3) = '$kode'
            AND substring(i_adjustment, 5, 2) = substring('$thbl',1,2)",$files);

	$rep2 = str_replace("AND substring(i_btb, 1, 3) = '$kode'", "AND substring(i_btb, 1, 3) = '$kode'
            AND substring(i_btb, 5, 2) = substring('$thbl',1,2)",$files);

	$rep3 = str_replace("AND substring(i_document, 1, 3) = '$kode'", "AND substring(i_document, 1, 3) = '$kode'
            AND substring(i_document, 5, 2) = substring('$thbl',1,2)",$files);

	$rep4 = str_replace("AND substring(i_keluar_jahit, 1, 3) = '$kode'", "AND substring(i_keluar_jahit, 1, 3) = '$kode'
            AND substring(i_keluar_jahit, 5, 2) = substring('$thbl',1,2)",$files);

	$rep5 = str_replace("AND substring(i_keluar_packing, 1, 3) = '$kode'", "AND substring(i_keluar_packing, 1, 3) = '$kode'
            AND substring(i_keluar_packing, 5, 2) = substring('$thbl',1,2)",$files);

	$rep6 = str_replace("AND substring(i_keluar_pengadaan, 1, 3) = '$kode'", "AND substring(i_keluar_pengadaan, 1, 3) = '$kode'
            AND substring(i_keluar_pengadaan, 5, 2) = substring('$thbl',1,2)",$files);

	$rep7 = str_replace("AND substring(i_keluar_qc, 1, 3) = '$kode'", "AND substring(i_keluar_qc, 1, 3) = '$kode'
            AND substring(i_keluar_qc, 5, 2) = substring('$thbl',1,2)",$files);

	$rep8 = str_replace("AND substring(i_keluar_qcset, 1, 3) = '$kode'", "AND substring(i_keluar_qcset, 1, 3) = '$kode'
            AND substring(i_keluar_qcset, 5, 2) = substring('$thbl',1,2)",$files);

	$rep9 = str_replace("AND substring(i_retur, 1, 3) = '$kode'", "AND substring(i_retur, 1, 3) = '$kode'
            AND substring(i_retur, 5, 2) = substring('$thbl',1,2)",$files);

	$rep10 = str_replace("AND substring(i_retur_beli, 1, 3) = '$kode'", "AND substring(i_retur_beli, 1, 3) = '$kode'
            AND substring(i_retur_beli, 5, 2) = substring('$thbl',1,2)",$files);

	$rep11 = str_replace("AND substring(i_dn_ap_retur_beli, 1, 2) = '$kode'", "AND substring(i_dn_ap_retur_beli, 1, 2) = '$kode'
            AND substring(i_dn_ap_retur_beli, 4, 2) = substring('$thbl',1,2)",$files);

	$rep12 = str_replace("AND substring(i_document, 1, 2) = '$kode'", "AND substring(i_document, 1, 2) = '$kode'
            AND substring(i_document, 4, 2) = substring('$thbl',1,2)",$files);

	$rep13 = str_replace("AND substring(i_nota, 1, 2) = '$kode'", "AND substring(i_nota, 1, 2) = '$kode'
            AND substring(i_nota, 4, 2) = substring('$thbl',1,2)",$files);

	$rep14 = str_replace("AND substring(i_op, 1, 2) = '$kode'", "AND substring(i_op, 1, 2) = '$kode'
            AND substring(i_op, 4, 2) = substring('$thbl',1,2)",$files);

	$rep15 = str_replace("AND substring(i_pp, 1, 2) = '$kode'", "AND substring(i_pp, 1, 2) = '$kode'
            AND substring(i_pp, 4, 2) = substring('$thbl',1,2)",$files);*/

	/*$files = file_get_contents($src);

	$rep  = str_replace($string, $replace ,$files);

	file_put_contents($src,$rep);*/

}

?>